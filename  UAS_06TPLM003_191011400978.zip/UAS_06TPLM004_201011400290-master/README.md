# uas_06tplm004_201011400290

<h3>UAS Mobile Programming</h3>

<p>Nama  : Aldo Alfiansyah</p>
<p>NIM   : 201011400290</p>
<p>Kelas : 06TPLM004</p>

