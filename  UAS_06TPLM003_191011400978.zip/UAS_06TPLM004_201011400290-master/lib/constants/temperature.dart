double kCoolOrHot = 297.15; //kelvin temp
